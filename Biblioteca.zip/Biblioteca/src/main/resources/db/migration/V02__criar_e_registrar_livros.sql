CREATE TABLE `book` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(50) NOT NULL,
  `autor` varchar(50) NOT NULL,
  `isbn` varchar(150) NOT NULL,
  `editora` varchar (150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO book (id, titulo, autor, isbn, editora) 
	values (1, 'Os Miseraveis', 'Victor Hugo', '1569875983654', 'Martin Claret');
INSERT INTO book (id, titulo, autor, isbn, editora) 
	values (2, 'Cem Anos de Solidão', 'Gabriel Garcia Marques', '4589652358798', 'Record');
INSERT INTO book (id, titulo, autor, isbn, editora) 
	values (3, 'Crime e Castigo', 'Fiodor Dostoievski', '4589652355988', 'Editora 34');