CREATE TABLE emprestimo (
	id BIGINT(20) PRIMARY KEY AUTO_INCREMENT,
	dataEmprestimo DATE NOT NULL,
	dataDevolucao DATE NOT NULL,
	devolvido tinyint(1) NOT NULL,
	user_id BIGINT(20) NOT NULL,
	book_id BIGINT(20) NOT NULL,
	FOREIGN KEY (user_id) REFERENCES user(id),
	FOREIGN KEY (book_id) REFERENCES book(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO emprestimo (id, dataEmprestimo, dataDevolucao, devolvido, user_id, book_id) 
	values (1, '2025-01-15', '2025-01-30', 1, 1, 2);
INSERT INTO emprestimo (id, dataEmprestimo, dataDevolucao, devolvido, user_id, book_id) 
	values (2, '2025-02-10', '2025-02-25', 1, 2, 1);
INSERT INTO emprestimo (id, dataEmprestimo, dataDevolucao, devolvido, user_id, book_id) 
	values (3, '2025-03-05', '2025-03-20', 2, 3, 3);
