CREATE TABLE `user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(150) NOT NULL,
  `birth_date` date NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO user (id, name, email, password, birth_date, active) 
	values (1, 'Fernando Duarte', 'fernandoduarte@ifsp.edu.br', 'senha', '1975-11-16', 1);
INSERT INTO user (id, name, email, password, birth_date, active) 
	values (2, 'Gislaine Rosales', 'gislainerosales@ifsp.edu.br', 'senha', '1980-01-01', 1);
INSERT INTO user (id, name, email, password, birth_date, active) 
	values (3, 'Priscila Rodrigues', 'priscilarodrigues@ifsp.edu.br', 'senha', '1989-01-28', 1);