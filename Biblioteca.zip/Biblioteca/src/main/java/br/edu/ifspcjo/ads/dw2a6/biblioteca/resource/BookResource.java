package br.edu.ifspcjo.ads.dw2a6.biblioteca.resource;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import br.edu.ifspcjo.ads.dw2a6.biblioteca.domain.model.Book;
import br.edu.ifspcjo.ads.dw2a6.biblioteca.repository.BookRepository;
import jakarta.servlet.http.HttpServletResponse;

@RestController
@RequestMapping("/books")
public class BookResource {
	
	@Autowired
	private BookRepository bookRepository;
	
	@GetMapping
	public List<Book> list(){
		return bookRepository.findAll();
	}
	
	@PostMapping
	public Book create(@RequestBody Book book, HttpServletResponse response) {
		return bookRepository.save(book);
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<Book> findById(@PathVariable Long id){
		Optional<Book> book = bookRepository.findById(id);
		if(book.isPresent()) {
			return ResponseEntity.ok(book.get());
		}
		return ResponseEntity.notFound().build();
	}
	
	@DeleteMapping("/{id}")
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void remove(@PathVariable Long id) {
		bookRepository.deleteById(id);
	}
	
}