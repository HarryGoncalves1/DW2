package br.edu.ifspcjo.ads.dw2a6.biblioteca.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.edu.ifspcjo.ads.dw2a6.biblioteca.domain.model.Book;

public interface BookRepository extends JpaRepository<Book, Long>{

}
