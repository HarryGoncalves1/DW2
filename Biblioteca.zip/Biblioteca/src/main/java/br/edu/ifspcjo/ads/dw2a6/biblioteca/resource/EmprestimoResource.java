package br.edu.ifspcjo.ads.dw2a6.biblioteca.resource;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import br.edu.ifspcjo.ads.dw2a6.biblioteca.domain.model.Emprestimo;
import br.edu.ifspcjo.ads.dw2a6.biblioteca.repository.EmprestimoRepository;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/emprestimos")
public class EmprestimoResource {

	@Autowired
	private EmprestimoRepository emprestimoRepository;
	
	@GetMapping
	public List<Emprestimo> list(){
		return emprestimoRepository.findAll();
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<Emprestimo> findById(@PathVariable Long id) {
		Optional<Emprestimo> emprestimo = emprestimoRepository.findById(id);
		if(emprestimo.isPresent()) {
			return ResponseEntity.ok(emprestimo.get());
		}
		return ResponseEntity.notFound().build();
	}
	
	@PostMapping
	@ResponseStatus(HttpStatus.CREATED)
	public Emprestimo create(@Valid @RequestBody Emprestimo emprestimo) {
		return emprestimoRepository.save(emprestimo);
	}
}

