package br.edu.ifspcjo.ads.dw2a6.biblioteca.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

import br.edu.ifspcjo.ads.dw2a6.biblioteca.domain.model.Book;
import br.edu.ifspcjo.ads.dw2a6.biblioteca.repository.BookRepository;

@Service
public class BookService {
	
	@Autowired
	private BookRepository bookRepository;
	
	public Book findUserById(Long id) {
		Book bookSaved = bookRepository.findById(id).orElseThrow(() -> new EmptyResultDataAccessException(1));
		return bookSaved;
	}
}