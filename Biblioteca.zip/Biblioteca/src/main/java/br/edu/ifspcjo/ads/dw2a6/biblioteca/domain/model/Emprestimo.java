package br.edu.ifspcjo.ads.dw2a6.biblioteca.domain.model;
import java.time.LocalDate;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;



@Entity
public class Emprestimo {
 
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;
	    @Column(name = "dataEmprestimo")
		@JsonFormat(pattern =  "dd/MM/yyyy")
	    private LocalDate dataEmprestimo;
	    @Column(name = "dataDevolucao")
		@JsonFormat(pattern =  "dd/MM/yyyy")
	    private LocalDate dataDevolucao;
	    private boolean devolvido;

	    public Emprestimo() {}

	    public Emprestimo(String book, String user) {
	        this.dataEmprestimo = LocalDate.now();
	        this.setDevolvido(false);
	    }

	    public void registrarDevolucao() {
	        this.dataDevolucao = LocalDate.now();
	        this.setDevolvido(true);
	    }
	
	public Long getId() {
		Long id = null;
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getBook() {
		return getBook();
	}
	public void setBook(String book) {
	}
	public String getUser() {
		return getUser();
	}
	public void setUser(String user) {
	}
	public LocalDate getDataEmprestimo() {
		return dataEmprestimo;
	}
	public void setDataEmprestimo(LocalDate dataEmprestimo) {
		this.dataEmprestimo = dataEmprestimo;
	}
	public LocalDate getDataDevolucao() {
		return dataDevolucao;
	}
	public void setDataDevolucao(LocalDate dataDevolucao) {
		this.dataDevolucao = dataDevolucao;
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	public boolean isDevolvido() {
		return devolvido;
	}

	public void setDevolvido(boolean devolvido) {
		this.devolvido = devolvido;
	}
}
